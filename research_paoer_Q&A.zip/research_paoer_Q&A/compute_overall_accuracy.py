import json
import os

# Load evaluation log from the correct path
eval_log_path = os.path.expanduser("~/paperbot_evaluation_log.json")
with open(eval_log_path, "r") as f:
    eval_log = json.load(f)

# Compute average metrics
total_entries = len(eval_log)
if total_entries == 0:
    print("No evaluation entries found.")
else:
    avg_bleu = sum(entry["metrics"]["BLEU"] for entry in eval_log if entry["metrics"]) / total_entries
    avg_rouge1 = sum(entry["metrics"]["ROUGE-1"] for entry in eval_log if entry["metrics"]) / total_entries
    avg_rougel = sum(entry["metrics"]["ROUGE-L"] for entry in eval_log if entry["metrics"]) / total_entries
    avg_bertscore = sum(entry["metrics"]["BERTScore"] for entry in eval_log if entry["metrics"]) / total_entries
    avg_correctness = sum(entry["manual_scores"]["correctness"] for entry in eval_log if entry["manual_scores"]) / total_entries
    avg_completeness = sum(entry["manual_scores"]["completeness"] for entry in eval_log if entry["manual_scores"]) / total_entries
    avg_relevance = sum(entry["manual_scores"]["relevance"] for entry in eval_log if entry["manual_scores"]) / total_entries

    # Compute overall accuracy (weighted combination)
    automated_score = (avg_bleu + avg_rouge1 + avg_rougel + avg_bertscore) / 4
    manual_score = (avg_correctness + avg_completeness + avg_relevance) / 3 / 5  # Normalize to 0-1
    overall_accuracy = 0.5 * automated_score + 0.5 * manual_score

    print(f"Average BLEU: {avg_bleu:.3f}")
    print(f"Average ROUGE-1: {avg_rouge1:.3f}")
    print(f"Average ROUGE-L: {avg_rougel:.3f}")
    print(f"Average BERTScore: {avg_bertscore:.3f}")
    print(f"Average Correctness: {avg_correctness:.1f}/5")
    print(f"Average Completeness: {avg_completeness:.1f}/5")
    print(f"Average Relevance: {avg_relevance:.1f}/5")
    print(f"Overall Accuracy: {overall_accuracy:.3f} ({overall_accuracy * 100:.1f}%)")