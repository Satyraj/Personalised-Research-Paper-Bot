import os
import logging
import traceback
import json
import streamlit as st
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFacePipeline
from langchain.chains import RetrievalQA
from langchain.prompts import PromptTemplate
from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, pipeline
import torch
from transformers import StoppingCriteria, StoppingCriteriaList
import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer
from bert_score import score

# Download required NLTK data
nltk.download('punkt')
nltk.download('punkt_tab')

# Set up logging
logging.basicConfig(
    filename="app.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Ensure directories exist
UPLOAD_DIR = "./uploads"
FAISS_DIR = "./faiss_index"
EVAL_LOG_PATH = os.path.expanduser("~/paperbot_evaluation_log.json")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(FAISS_DIR, exist_ok=True)
try:
    os.makedirs(os.path.dirname(EVAL_LOG_PATH), exist_ok=True)
    # Test write permissions by creating an empty file
    with open(EVAL_LOG_PATH, "a") as f:
        pass
    logger.info(f"Evaluation log path is writable: {EVAL_LOG_PATH}")
except Exception as e:
    logger.error(f"Cannot write to evaluation log path {EVAL_LOG_PATH}: {str(e)}")
    st.error(f"Cannot write to evaluation log path {EVAL_LOG_PATH}: {str(e)}")

# Initialize Streamlit session state
if "vector_store" not in st.session_state:
    st.session_state.vector_store = None
if "qa_chain" not in st.session_state:
    st.session_state.qa_chain = None
if "debug_mode" not in st.session_state:
    st.session_state.debug_mode = False
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Sidebar for configuration
with st.sidebar:
    st.title("Configuration")
    st.session_state.debug_mode = st.checkbox("Debug Mode", value=False)
    st.markdown("---")
    st.write("Model Options:")
    model_choice = st.selectbox(
        "Choose LLM",
        ["flan-t5-base"],
        index=0
    )
    use_8bit = st.checkbox("Use 8-bit quantization (saves memory)", value=False)  # Disabled by default
    chunk_size = st.slider("Document Chunk Size", min_value=500, max_value=2000, value=1000)
    overlap = st.slider("Chunk Overlap", min_value=0, max_value=300, value=100)
    retriever_k = st.slider("Number of passages to retrieve", min_value=3, max_value=15, value=5)

def load_and_process_documents(file_paths):
    """Load and split documents into chunks with deduplication."""
    try:
        documents = []
        for file_path in file_paths:
            logger.info(f"Loading file: {file_path}")
            if file_path.endswith(".pdf"):
                loader = PyPDFLoader(file_path)
            elif file_path.endswith(".txt"):
                loader = TextLoader(file_path)
            else:
                logger.warning(f"Unsupported file type: {file_path}")
                continue
            documents.extend(loader.load())
        
        if not documents:
            logger.error("No valid documents loaded")
            return None
        
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=overlap,
            separators=["\n\n", "\n", ".", " ", ""],
            length_function=len
        )
        chunks = text_splitter.split_documents(documents)
        logger.info(f"Created {len(chunks)} document chunks")
        
        seen_content = set()
        unique_chunks = []
        for chunk in chunks:
            simplified = ' '.join(chunk.page_content.split()[:50])
            if simplified not in seen_content:
                seen_content.add(simplified)
                unique_chunks.append(chunk)
        
        logger.info(f"After deduplication: {len(unique_chunks)} unique chunks")
        return unique_chunks
    except Exception as e:
        logger.error(f"Error processing documents: {str(e)} with traceback: {traceback.format_exc()}")
        return None

def create_vector_store(chunks):
    """Create or load FAISS vector store."""
    try:
        embedding_model = HuggingFaceEmbeddings(model_name="BAAI/bge-small-en-v1.5")
        logger.info("Embedding model initialized")
        
        faiss_index_path = os.path.join(FAISS_DIR, "index")
        
        try:
            sample_embedding = embedding_model.embed_query("test")
            logger.info(f"Sample embedding shape: {len(sample_embedding)}")
        except Exception as emb_error:
            logger.error(f"Embedding test failed: {str(emb_error)}")
            return None
        
        logger.info("Creating new FAISS index")
        vector_store = FAISS.from_documents(chunks, embedding_model)
        
        vector_store.save_local(faiss_index_path)
        logger.info("Vector store created and saved")
        return vector_store
    except Exception as e:
        logger.error(f"Error creating vector store: {str(e)} with traceback: {traceback.format_exc()}")
        return None

class StopOnTokens(StoppingCriteria):
    def __init__(self, stop_token_ids):
        self.stop_token_ids = stop_token_ids
    
    def __call__(self, input_ids, scores, **kwargs):
        for stop_id in self.stop_token_ids:
            if input_ids[0][-1] == stop_id:
                return True
        return False

def initialize_llm():
    """Initialize FLAN-T5-base LLM for RAG with stopping criteria."""
    try:
        model_name = "google/flan-t5-base"
        logger.info(f"Initializing {model_name}")
        
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model_kwargs = {
            "torch_dtype": torch.float16 if torch.cuda.is_available() else torch.float32,
            "load_in_8bit": use_8bit and torch.cuda.is_available(),
            "device_map": "auto" if torch.cuda.is_available() else None
        }
        model = AutoModelForSeq2SeqLM.from_pretrained(model_name, **model_kwargs)
        
        stop_token_ids = [tokenizer.eos_token_id] if tokenizer.eos_token_id else []
        stopping_criteria = StoppingCriteriaList([StopOnTokens(stop_token_ids)])
        
        hf_pipeline = pipeline(
            "text2text-generation",
            model=model,
            tokenizer=tokenizer,
            max_length=256,
            max_new_tokens=32,
            temperature=0.1,
            do_sample=False,
            num_return_sequences=1,
            stopping_criteria=stopping_criteria
        )
        
        llm = HuggingFacePipeline(pipeline=hf_pipeline)
        logger.info(f"LLM initialized successfully with {model_name}")
        return llm
    except Exception as e:
        logger.error(f"Failed to initialize LLM: {str(e)} with traceback: {traceback.format_exc()}")
        return None

def create_rag_chain(vector_store, llm):
    """Create RAG pipeline with improved prompt template."""
    try:
        if not vector_store:
            raise ValueError("Vector store is not initialized")
        if not llm:
            raise ValueError("LLM is not initialized")

        prompt_template = """You are a precise research assistant. Based ONLY on the context below, provide a single-sentence answer to the question. For 'how' questions, explain the mechanism; for 'why' questions, state the purpose or benefit. If no relevant information is found, respond with 'I don't have enough information.'

Context: {context}

Question: {question}"""
        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["context", "question"]
        )
        
        retriever = vector_store.as_retriever(
            search_type="mmr",
            search_kwargs={"k": retriever_k, "fetch_k": retriever_k * 2}
        )
        
        test_query = "test"
        test_docs = retriever.get_relevant_documents(test_query)
        if not test_docs:
            logger.warning("Retriever returned no documents in test - using default retriever")
            retriever = vector_store.as_retriever(search_kwargs={"k": retriever_k})

        qa_chain = RetrievalQA.from_chain_type(
            llm=llm,
            chain_type="stuff",
            retriever=retriever,
            return_source_documents=True,
            chain_type_kwargs={"prompt": prompt}
        )
        logger.info("RAG chain created successfully")
        return qa_chain
    except Exception as e:
        logger.error(f"Error creating RAG chain: {str(e)} with traceback: {traceback.format_exc()}")
        return None

# Function to compute accuracy metrics
def compute_accuracy_metrics(ground_truth, bot_answer):
    """Compute BLEU, ROUGE, and BERTScore for the bot's answer."""
    try:
        metrics = {}
        
        # Tokenize for BLEU
        reference = [nltk.word_tokenize(ground_truth.lower())]
        hypothesis = nltk.word_tokenize(bot_answer.lower())
        smoothie = SmoothingFunction().method4
        bleu_score = sentence_bleu(reference, hypothesis, smoothing_function=smoothie)
        metrics["BLEU"] = round(bleu_score, 3)

        # Compute ROUGE
        scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
        rouge_scores = scorer.score(ground_truth, bot_answer)
        metrics["ROUGE-1"] = round(rouge_scores['rouge1'].fmeasure, 3)
        metrics["ROUGE-L"] = round(rouge_scores['rougeL'].fmeasure, 3)

        # Use a lighter model for BERTScore
        P, R, F1 = score([bot_answer], [ground_truth], lang="en", model_type="distilbert-base-uncased", verbose=False)
        metrics["BERTScore"] = round(F1.mean().item(), 3)

        logger.info(f"Computed metrics: {metrics}")
        return metrics
    except Exception as e:
        logger.error(f"Error computing metrics: {str(e)} with traceback: {traceback.format_exc()}")
        raise

# Function to log evaluation results
def log_evaluation_result(question, bot_answer, ground_truth, metrics, manual_scores=None):
    """Log evaluation results to a JSON file."""
    try:
        logger.info(f"Logging evaluation result for question: {question}")
        eval_entry = {
            "question": question,
            "bot_answer": bot_answer,
            "ground_truth": ground_truth,
            "metrics": metrics,
            "manual_scores": manual_scores
        }
        
        # Load existing log if it exists
        eval_log = []
        if os.path.exists(EVAL_LOG_PATH):
            try:
                with open(EVAL_LOG_PATH, "r") as f:
                    eval_log = json.load(f)
                logger.info(f"Loaded existing evaluation log with {len(eval_log)} entries")
            except Exception as e:
                logger.error(f"Error reading existing evaluation log: {str(e)}")
                eval_log = []

        # Append new entry
        eval_log.append(eval_entry)
        logger.info("Appended new evaluation entry")

        # Save updated log
        with open(EVAL_LOG_PATH, "w") as f:
            json.dump(eval_log, f, indent=4)
        logger.info(f"Evaluation log saved to {EVAL_LOG_PATH}")
        st.success(f"Evaluation logged to {EVAL_LOG_PATH}")
    except Exception as e:
        logger.error(f"Error logging evaluation result: {str(e)} with traceback: {traceback.format_exc()}")
        st.error(f"Failed to log evaluation: {str(e)}")

# Streamlit app
st.title("Personalised Research Assistant!!")
st.markdown("Upload PDFs or text files to create a knowledge base, then ask questions about the content.")

# File upload
uploaded_files = st.file_uploader(
    "Upload PDFs or Text Files",
    accept_multiple_files=True,
    type=["pdf", "txt"]
)

if uploaded_files:
    file_paths = []
    for uploaded_file in uploaded_files:
        file_path = os.path.join(UPLOAD_DIR, uploaded_file.name)
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        file_paths.append(file_path)
        st.success(f"Uploaded: {uploaded_file.name}")
    
    with st.spinner("Processing documents..."):
        chunks = load_and_process_documents(file_paths)
        if chunks:
            vector_store = create_vector_store(chunks)
            if vector_store:
                st.session_state.vector_store = vector_store
                
                with st.spinner("Initializing language model..."):
                    llm = initialize_llm()
                    if llm:
                        qa_chain = create_rag_chain(vector_store, llm)
                        if qa_chain:
                            st.session_state.qa_chain = qa_chain
                            st.success("Knowledge base created successfully!")
                        else:
                            st.error("Failed to create RAG pipeline. Check app.log for details.")
                    else:
                        st.error("Failed to initialize LLM. Check app.log for details.")
            else:
                st.error("Failed to create vector store. Check app.log for details.")
        else:
            st.error("Failed to process documents. Ensure files are valid PDFs or text files.")

# Chat interface
st.markdown("### Chat with Research Assistant")

# Display chat history
if st.session_state.chat_history:
    for idx, entry in enumerate(st.session_state.chat_history):
        st.markdown(f"**You:** {entry['question']}")
        st.markdown(f"**Assistant:** {entry['answer']}")
        if "source_docs" in entry and entry["source_docs"] and st.session_state.debug_mode:
            st.markdown("#### Source Documents:")
            for i, doc in enumerate(entry["source_docs"]):
                source = doc.metadata.get("source", "Unknown")
                page = doc.metadata.get("page", "N/A")
                st.write(f"- {source} (Page {page})")
        if "metrics" in entry and entry["metrics"]:
            st.markdown("#### Accuracy Metrics:")
            st.write(f"- BLEU: {entry['metrics']['BLEU']}")
            st.write(f"- ROUGE-1: {entry['metrics']['ROUGE-1']}")
            st.write(f"- ROUGE-L: {entry['metrics']['ROUGE-L']}")
            st.write(f"- BERTScore: {entry['metrics']['BERTScore']}")
        if "manual_scores" in entry and entry["manual_scores"]:
            st.markdown("#### Manual Evaluation:")
            st.write(f"- Correctness: {entry['manual_scores']['correctness']}/5")
            st.write(f"- Completeness: {entry['manual_scores']['completeness']}/5")
            st.write(f"- Relevance: {entry['manual_scores']['relevance']}/5")
        st.markdown("---")

# Query input and evaluation form
with st.form(key="chat_form", clear_on_submit=True):
    query = st.text_input(
        "Ask a question about your documents:",
        placeholder="E.g., What is self-attention?"
    )
    ground_truth = st.text_area(
        "Provide the ground truth answer (optional, for evaluation):",
        placeholder="Enter the expected answer to evaluate the bot's accuracy."
    )
    st.markdown("**Manual Evaluation (optional)**")
    col1, col2, col3 = st.columns(3)
    with col1:
        correctness = st.slider("Correctness (1-5)", min_value=1, max_value=5, value=3)
    with col2:
        completeness = st.slider("Completeness (1-5)", min_value=1, max_value=5, value=3)
    with col3:
        relevance = st.slider("Relevance (1-5)", min_value=1, max_value=5, value=3)
    submit_button = st.form_submit_button("Send")

if submit_button and query:
    if st.session_state.qa_chain:
        try:
            with st.spinner("Generating answer..."):
                result = st.session_state.qa_chain.invoke({"query": query})
                answer = result["result"].strip().split('.')[0] + '.' if '.' in result["result"] else result["result"].strip()
                source_docs = result["source_documents"]
                
                # Initialize chat entry
                chat_entry = {
                    "question": query,
                    "answer": answer,
                    "source_docs": source_docs,
                    "metrics": None,
                    "manual_scores": None
                }
                
                # Compute accuracy metrics if ground truth is provided
                if ground_truth and ground_truth.strip():
                    metrics = compute_accuracy_metrics(ground_truth, answer)
                    chat_entry["metrics"] = metrics
                else:
                    metrics = None
                    st.warning("No ground truth provided. Skipping metrics computation and logging.")

                # Add manual scores
                manual_scores = {
                    "correctness": correctness,
                    "completeness": completeness,
                    "relevance": relevance
                }
                chat_entry["manual_scores"] = manual_scores
                
                # Add to chat history
                st.session_state.chat_history.append(chat_entry)
                
                # Log evaluation results only if metrics were computed
                if metrics:
                    log_evaluation_result(query, answer, ground_truth, metrics, manual_scores)
                else:
                    logger.info("Skipping logging because no metrics were computed (no ground truth).")
                
                logger.info(f"Query: {query}, Answer: {answer}")
        except Exception as e:
            st.error("Error generating answer. Please try again.")
            logger.error(f"Error processing query '{query}': {str(e)} with traceback: {traceback.format_exc()}")
            if st.session_state.debug_mode:
                st.error(f"Error details: {str(e)}")
                st.code(traceback.format_exc())
    else:
        st.error("No knowledge base available. Please upload documents first.")

# Footer
st.markdown("---")
st.markdown("Built by Satyarajsinh Jadeja.")